import { Component, inject } from '@angular/core';
import { MonitorControllerService } from '@openapi2/index';
import { monitorControllerConfigBean, monitorControllerEntitiesBean, MonitorControllerEntityTypeBean, MonitorControllerHealthBean, MonitorControllerMetricsBean, MonitorControllerStatusBean } from '@openapi2/model/monitorControllerBean';
import { CommonModule } from '@angular/common';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-view-monitoring-errors-output',
  imports: [CommonModule],
  templateUrl: './view-monitoring-errors-output.html',
  styleUrls: ['./view-monitoring-errors-output.scss'],
})
export class ViewMonitoringErrorsOutput {

  showConfig = false;
  // Estados para la UI
  loading: boolean = false;
  errorMessage: string | null = null;
  //Inyectamos el servicio de OpenApi
  private monitorControllerService = inject(MonitorControllerService);

  // Datos que vendrán de la API
  monitor_config: monitorControllerConfigBean | null = null;
  monitor_health: MonitorControllerHealthBean | null = null;
  monitor_status: MonitorControllerStatusBean | null = null;
  monitor_metrics: MonitorControllerMetricsBean | null = null;
  monitor_entities: monitorControllerEntitiesBean[] = [];
  monitor_entities_type: MonitorControllerEntityTypeBean | null = null;

  //Metodo para esconder el contenido de configuracion del sistema
  toggleConfig(): void {
    this.showConfig = !this.showConfig;
  }

  //Datos que se recogen de la API al cargar la página
  ngOnInit() {
    //Cargamos todas las llamadas necesarias a las apis
    this.getMonitorConfig();
    this.getMonitorStatus();
    this.getMonitorHealth();
    this.loadConfiguredEntities();
  }

  //Recoger datos del config monitor
  getMonitorConfig() {
    this.loading = true;
    this.errorMessage = null;

    this.monitorControllerService.getConfig().subscribe({
      next: (data) => {
        this.monitor_config = data ?? null;
        this.loading = false;
        this.buildTopicsConfigRows();
      },
      error: (err) => {
        this.errorMessage = 'Error cargando configuración';
        this.loading = false;
      }
    });
  }

  getMonitorStatus() {
    this.loading = true;
    this.errorMessage = null;

    this.monitorControllerService.getStatus().subscribe({
      next: (data) => {
        this.monitor_status = data ?? null;
        this.loading = false;
        this.buildTopicsConfigRows();
      },
      error: (err) => {
        this.errorMessage = 'Error cargando configuración';
        this.loading = false;
      }
    });
  }

  getMonitorHealth() {
    this.loading = true;
    this.errorMessage = null;

    this.monitorControllerService.getHealth().subscribe({
      next: (data) => {
        this.monitor_health = data ?? [];
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = 'Error cargando configuración';
        this.loading = false;
      }
    });
  }

  formatSuccessRate(rate: number | undefined | null): string {
    if (rate == null) return '0%';
    return (rate * 100).toFixed(1) + '%';
  }

  formatUptime(ms: number | undefined | null): string {
    if (!ms) return '0d 0h';
    const totalHours = Math.floor(ms / 1000 / 60 / 60);
    const days = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    return `${days}d ${hours}h`;
  }

  isHealthHealthy(): boolean {
    return (
      this.monitor_health?.health === 'HEALTHY' &&
      this.monitor_health?.status === 'HEALTHY'
    );
  }

  getMonitorEntities() {
    this.loading = true;
    this.errorMessage = null;

    this.monitorControllerService.getEntities().subscribe({
      next: (data) => {
        this.monitor_entities = data ?? null;
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = 'Error cargando configuración';
        this.loading = false;
      }
    });
  }

  getMonitorEntitiesType(tipo: any) {
    this.loading = true;
    this.errorMessage = null;

    this.monitorControllerService.getEntityConfig(tipo).subscribe({
      next: (data) => {
        this.monitor_entities_type = data ?? null;
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = 'Error cargando configuración';
        this.loading = false;
      }
    });
  }

  getMonitorMetrics() {
    this.loading = true;
    this.errorMessage = null;

    this.monitorControllerService.getMetrics().subscribe({
      next: (data) => {
        this.monitor_metrics = data ?? null;
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = 'Error cargando configuración';
        this.loading = false;
      }
    });
  }

  getMonitorMetricsEntities(type: any) {
    forkJoin({
      entities: this.monitorControllerService.getEntities(),
      entitiestype: this.monitorControllerService.getEntityConfig(type)
    }).subscribe(({ entities, entitiestype }) => {
      const resultado = entities.map(u => ({
        entitiestype: entities.filter(p => p.name === u.name)
      }));
      console.log(resultado);
    });
  }

  configuredEntitiesRows: Array<{
    type?: string;
    name?: string;
    serviceBean?: string;
    received: number;
    success: number;
    failure: number;
    successRate: number | null;
    avgTimeMs: number;
    status: 'ACTIVE' | 'INACTIVE';
  }> = [];

  topicsConfigRows: Array<{
    type: string;
    topicId: string;
    consumerGroup: string;
    status: 'CONNECTED' | 'DISCONNECTED';
  }> = [];

  loadConfiguredEntities() {
    this.loading = true;
    this.errorMessage = null;

    forkJoin({
      entities: this.monitorControllerService.getEntities(),
      metrics: this.monitorControllerService.getMetrics()
    }).subscribe({
      next: ({ entities, metrics }) => {
        const metricsEntities = metrics?.entities ?? {};

        this.configuredEntitiesRows = (entities ?? []).map(entity => {
          const name = entity.name ?? '';

          // Buscamos en metrics.entities por el nombre (promotions, rates, warehouse, etc.)
          const m = (metricsEntities as any)[name] as
            | {
              process_time_avg: number;
              success: number;
              failure: number;
              received: number;
            }
            | undefined;

          const received = m?.received ?? 0;
          const success = m?.success ?? 0;
          const failure = m?.failure ?? 0;
          const avgTimeMs = m?.process_time_avg ?? 0;
          const successRate =
            received > 0 ? (success / received) * 100 : null;

          const status: 'ACTIVE' | 'INACTIVE' =
            received === 0 && success === 0 && failure === 0
              ? 'INACTIVE'
              : 'ACTIVE';

          return {
            type: entity.type,
            name: entity.name,
            serviceBean: entity.serviceBean,
            received,
            success,
            failure,
            successRate,
            avgTimeMs,
            status
          };
        });

        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Error cargando entidades configuradas';
        this.loading = false;
      }
    });
  }

  private buildTopicsConfigRows(): void {
    if (!this.monitor_config) {
      this.topicsConfigRows = [];
      return;
    }

    // estado general del consumidor (lo usamos como estado de los topics)
    const isConnected =
      this.monitor_status?.consumer?.running &&
      this.monitor_status?.consumer?.healthy;

    const statusLabel: 'CONNECTED' | 'DISCONNECTED' =
      isConnected ? 'CONNECTED' : 'DISCONNECTED';

    this.topicsConfigRows = [
      {
        type: 'Main Topic',
        topicId: this.monitor_config.topics?.main_topic ?? '-',
        consumerGroup: this.monitor_config.consumer?.group_id ?? 'N/A',
        status: statusLabel,
      },
      {
        type: 'Error Topic',
        topicId: this.monitor_config.topics?.error_topic ?? '-',
        consumerGroup: 'N/A',
        status: statusLabel,
      },
    ];
  }


}
