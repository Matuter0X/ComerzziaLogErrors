export * from './integrationErrors.service';
import { IntegrationErrorsService } from './integrationErrors.service';
export * from './monitorController.service';
import { MonitorControllerService } from './monitorController.service';
export const APIS = [IntegrationErrorsService, MonitorControllerService];
